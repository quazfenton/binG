export class DownedDockerComposeEnvironment {}
